# Estensione di prova

Esperimenti per un'estensione su chrome, realizzata a partire da una repository pre-esistente su GitHub. 
